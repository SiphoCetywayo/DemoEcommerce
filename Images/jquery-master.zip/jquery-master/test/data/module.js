window.ok( true, "evaluated: module with src" );
